<footer class="py-4 bg-black">
    <div class="container">
        <p class="m-0 text-center text-white small">Copyright &copy; Your Website 2018</p>
    </div>
</footer>

<script></script>
<script src="<?= base_url('assets/js/bootstrap.bundle.js') ?>"></script>
<script src="<?= base_url('assets/js/bootstrap.js') ?>"></script>
<script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
<script src="<?= base_url('assets/vendor/jquery/jquery.min.js') ?>"></script>
<script src="<?= base_url('assets/vendor/jquery-easing/jquery.easing.min.js') ?>"></script>
<script src="<?= base_url('assets/js/sb-admin.min.js') ?>"></script>
<script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')?>"></script>
<script src="<?= base_url('assets/js/jqBootstrapValidation.js')?>"></script>
<script src="<?= base_url('assets/js/contact_me.js')?>"></script>
<script src="<?= base_url('assets/js/agency.min.js')?>"></script>
<script src="<?= base_url('semantic/dist/semantic.min.js') ?>"></script>

</html>