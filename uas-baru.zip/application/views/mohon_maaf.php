<body>
    <h2>HALO <?=$siapa?></h2>
    <h1>MOHON MAAF, Anda tidak dapat mengakses halaman ini</h1>
    <p>Silahkan klik <a href="<?= base_url('user') ?>">disini</a> untuk kembali</p>
</body>